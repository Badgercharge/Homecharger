# OCPP WebSocket handler placeholder
