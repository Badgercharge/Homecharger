# Simulated OCPP charger placeholder
