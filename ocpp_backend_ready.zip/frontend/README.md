# Frontend placeholder for dashboard
